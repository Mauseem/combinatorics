from setuptools import setup

setup(name="combinatorics",
      version="0.1",
      description="This is a combinatorics package that helps to calculate factorial , permutation and combination",
      author="Mauseem",
      packages=["combinatorics"],
      install_requires=[])
