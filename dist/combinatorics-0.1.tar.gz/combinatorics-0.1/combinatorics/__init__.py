# Factorial
def factorial(n):
    fact = 1
    for i in range(1, n+1):
        fact = fact * i
    return fact

# combination


def combination(n, k):
    comb = (factorial(n)/(factorial(k)*factorial(n-k)))
    return comb

# permutation


def permutation(n, k):
    perm = (factorial(n)/factorial(n-k))
    return perm


# test cases -
# print(factorial(5))
# print(combination(5, 2))
# print(permutation(5, 2))
