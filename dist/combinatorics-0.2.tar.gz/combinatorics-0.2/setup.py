from setuptools import setup

setup(name="combinatorics",
      version="0.2",
      description="This is a combinatorics package that helps to calculate factorial , permutation and combination",
      author="Mauseem",
      packages=["combinatorics"],
      install_requires=[])
